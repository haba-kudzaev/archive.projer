/*! rx1310 <rx1310@inbox.ru> | Copyright (c) o1310, 2020 | MIT License */

function onShowAlert() {
  alert('This is alert!');
}